# REFIT appliance disaggregation take-home

This repository implements the four sections in the Flock Energy Data Science assignment:

1. Raw House 1 inspection and cleaning.
2. Washing-machine exploratory analysis using official cleaned REFIT data.
3. Washing-machine NILM using a held-out-house evaluation and NILMFormer.
4. Practical implications and a utility-facing recommendation.

## Setup and execution

Install dependencies:

```text
pip install -r refit/requirements.txt
```

Run individual sections from the repository root:

```text
python refit/main.py --section 1
python refit/main.py --section 2
python refit/main.py --section 3 --models nilmformer --train-houses 1 2 3 --test-house 4 --epochs 50
python refit/main.py --section 4
```

Use `--section all` to run the complete pipeline. Outputs are written below
`outputs/section1` through `outputs/section4`.

## Main choices and trade-offs

- Raw House 1 is sorted by timestamp; duplicate timestamps keep the last reading.
- Signals are resampled to one-minute arithmetic means. Internal gaps up to two minutes are interpolated; longer gaps remain missing.
- Washing-machine activity is defined as power above 10 W, allowing gaps of up to two minutes inside an event.
- Section 3 uses Houses 1–3 for training and entirely held-out House 4 for evaluation to avoid household leakage.
- NILMFormer uses 31-minute windows in this implementation. It stationarizes each input window, extracts convolutional shape features, adds a statistics token and timestamp-only TimeRPE, applies a Transformer encoder, and de-stationarizes the sequence prediction.
- The model is a research baseline, not a billing or automatic-control system.

## Research guidance and citations

The primary research method adopted is:

Petralia, A., Charpentier, P., Kadhi, Y., and Palpanas, T. “NILMFormer: Non-Intrusive Load Monitoring that Accounts for Non-Stationarity.” Proceedings of KDD 2025. DOI: [10.1145/3711896.3737251](https://doi.org/10.1145/3711896.3737251); open preprint: [arXiv:2506.05880](https://arxiv.org/abs/2506.05880).

The paper motivates handling distribution drift within subsequences. The implemented ideas are window stationarization using mean and standard deviation, a convolutional feature extractor, statistics tokens, timestamp-derived periodic encoding, Transformer sequence-to-sequence prediction, and statistics-based output de-stationarization. The implementation is adapted to one-minute REFIT data and the assignment's single-appliance target; it is not a claim of exact reproduction of the paper's experimental configuration.

The official implementation was also consulted for the architecture description: [github.com/adrienpetralia/NILMFormer](https://github.com/adrienpetralia/NILMFormer).

## AI tools used

AI assistance was used to inspect the assignment requirements, organize the reproducible pipeline, implement the Section 4 report, and adapt the NILMFormer architecture. All generated code was reviewed, locally executed, and evaluated against the supplied REFIT files. The research paper and official repository were checked as external sources rather than treated as generated facts.

See [DATA.md](DATA.md), [RESULTS.md](RESULTS.md), and [Recommendation.md](Recommendation.md) for the required deliverables.
