# Data, coverage, and quality

## Dataset

The project uses the REFIT Electrical Load Measurements dataset from the University of Strathclyde. Both the supplied raw archive and official cleaned files are retained locally. REFIT contains aggregate household power and appliance-level channels, with UK household measurements collected at approximately 8-second intervals before one-minute aggregation.

Dataset links: [REFIT dataset page](https://pureportal.strath.ac.uk/en/datasets/refit-electrical-load-measurements/) and [official cleaned-data readme](https://pure.strath.ac.uk/ws/portalfiles/portal/62090183/CLEAN_READ_ME_081116.txt).

## Section 1: raw House 1

The raw inspection found 8,518,763 rows from 2013-10-09 14:06:17 to 2015-07-10 11:56:32. No timestamps failed parsing. There were 761,551 duplicate timestamps; the cleaning rule keeps the last reading. The median raw interval was 6 seconds and the 99th-percentile interval was 15 seconds. There were 5,284,083 missing power cells, no negative power values, and 372 values above 30 kW.

After one-minute resampling there were 920,031 rows. At most two consecutive missing minutes were interpolated. Longer outages remain flagged/missing rather than being silently converted to zero. Full values are in `outputs/section1/house1_quality_report.json`.

## Section 2: washing machine

The current generated Section 2 report contains House 1, using `Appliance5` as the washing-machine channel. Coverage is 2013-10-09 13:06:00 to 2015-07-10 11:56:00, with 920,091 one-minute rows. The report records 116,318 missing washing-machine minutes, 98.24% off-time, 1,179 detected events, 14 minutes median duration, 495.3 W median peak power, and 41.4 Wh median event energy.

The event rule is power greater than 10 W, with gaps up to two minutes merged into the same event. These are detected operating events, not guaranteed manufacturer-defined cycles. Channel mappings for other available homes are documented in `outputs/section2/section2_report.json`.

## Section 3: model data

The model uses official cleaned data, one-minute aggregate input, and washing-machine labels. Houses 1–3 are training homes and House 4 is held out. Short internal gaps up to two minutes are interpolated; longer gaps are excluded from usable windows. The aggregate is scaled by 3,000 W for optimization and predictions are converted back to watts for metrics.

Important limitations are missing labels, appliance identity changes, unmetered loads, overlapping appliance signatures, and the fact that one-minute means smooth short transients.
