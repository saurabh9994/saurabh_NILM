# Results and interpretation

## Washing-machine EDA

The generated plots are in `outputs/section2/`:

- `representative_24h_trace.png`: aggregate and washing-machine power over a representative day.
- `representative_cycle.png`: detected washing-machine event shape.
- `usage_by_hour_and_day.png`: usage timing by hour and weekday.
- `cycle_comparison_by_house.png`: event duration, peak power, and energy comparisons.

House 1 has long periods of no detected washing-machine activity and relatively short detected events. The 10 W threshold and two-minute gap allowance are practical heuristics; they should not be interpreted as appliance manufacturer cycle boundaries.

## NILM evaluation and model comparison

The saved prediction files contain results for all five implemented models. The
metrics below were recomputed from those files using the same evaluation code:

| Model | MAE (W) | RMSE (W) | R² | Energy error | ON/OFF F1 | Predicted energy (kWh) |
|---|---:|---:|---:|---:|---:|---:|
| Seq2Point | 20.57 | 158.16 | 0.213 | -33.42% | 0.359 | 129.57 |
| Seq2Seq | 15.37 | 162.11 | 0.173 | -76.92% | 0.300 | 44.92 |
| TCN | 15.47 | 154.64 | 0.248 | -67.36% | 0.288 | 63.52 |
| CNN | 55.60 | 167.36 | 0.119 | +213.13% | 0.034 | 609.42 |
| NILMFormer | 21.37 | 157.67 | 0.204 | -21.31% | 0.087 | 11.69 |

The actual evaluated energy is 194.62 kWh for the full prediction files. NILMFormer
was evaluated on a 60,000-window sampled test subset in its latest run, where its
actual energy is 14.86 kWh; this is why its energy denominator differs from the
other saved files. The latest NILMFormer run uses 50 epochs, Houses 1–3 for
training, and House 4 for testing. The earlier baseline prediction files do not
retain their original epoch count in the current metadata, so their metrics are
reported as saved/recomputed results rather than claimed equal-budget comparisons.

The comparison shows that lower MAE does not necessarily mean better energy
calibration. Seq2Seq and TCN have lower MAE than NILMFormer but substantially
underestimate total energy. NILMFormer has the best energy calibration among the
saved models except for the overpredicting CNN, but its event F1 remains weak.

The current saved NILMFormer run reports:

| Metric | Result |
|---|---:|
| MAE | 21.37 W |
| RMSE | 157.67 W |
| R² | 0.204 |
| Energy error | -21.31% |
| ON/OFF F1 | 0.087 |
| Actual test energy | 14.86 kWh |
| Predicted test energy | 11.69 kWh |

The low F1 indicates that minute-level event classification remains weak even though average power error and energy calibration are better than the earlier one-epoch run. RMSE is much larger than MAE because high-power washing-machine intervals and false peaks dominate squared error. Predictions and metrics are in `outputs/section3/`.

## Validation design and leakage control

The split is by household rather than random rows. This prevents near-duplicate windows from the same home appearing in both training and evaluation. The test home's labels are never used for training. Evaluation uses actual versus predicted centre-minute power from the held-out windows.

## Research connection

NILMFormer was selected because the paper specifically addresses non-stationarity within segmented smart-meter windows. This implementation adopts its stationarization/de-stationarization strategy, timestamp-based periodic encoding, convolutional feature extraction, statistics token, and Transformer sequence-to-sequence design. The assignment implementation uses smaller windows and a compact model for workstation execution, so reported results are an adaptation rather than paper-reported results.

## Failure analysis and next steps

The appliance is off for most minutes, creating severe class imbalance. Overlapping loads can resemble washing-machine signatures, and missing intervals reduce label reliability. Recommended improvements are event-weighted or focal loss, more held-out homes, longer training with early stopping, calibration on a validation home, and separate event-level evaluation.
