# Practical implications and recommendation

## Evidence and suitable use

The current washing-machine analysis covers 1. For House 1, the available summary reports 1,179 detected events, a median duration of 14.0 minutes, median event energy of 41.4 Wh, and 98.2% off-time. The best recorded model by MAE is cnn: MAE 55.6 W, RMSE 167.4 W, and ON/OFF F1 0.034.

The model is suitable as an **aggregate-load screening signal**: it can help identify
likely washing-machine activity windows and compare usage patterns over groups of homes.
It is not reliable enough in its current form for appliance-level billing, customer
penalties, or automated control. The very low ON/OFF F1 means predicted events should
be reviewed or aggregated before being acted on.

## Energy-saving opportunity

A practical opportunity is to shift discretionary washing-machine cycles away from
the utility's peak period, or to encourage full-load and eco-cycle operation. The
recommended pilot is a time-of-use message or app prompt offered after a detected
cycle, with no automatic appliance control initially.

Measure impact with a pre/post comparison: record washing-machine event count, energy
per event, start-time distribution, and household aggregate evening peak demand for
four weeks before and four weeks after the intervention. Use comparable control homes
or a difference-in-differences design, and report confidence intervals. Ground-truth
submeter readings are preferable for the pilot; the NILM output should be treated as
an estimator and audited against labels.

## Limitations

- Multiple appliances can overlap in the aggregate signal, producing ambiguous signatures.
- Missing intervals and unmetered loads can hide or distort events; missingness must not be treated as zero use.
- One-minute data smooths short transients and may miss start/stop details.
- Household routines, appliance replacement, occupancy, and seasonality limit transfer between homes.
- The REFIT homes are UK homes. Appliance mix, voltage, tariffs, climate, and behaviour differ in India, so the findings should not be generalized without local validation.
- The current model's held-out performance is weak, especially for event classification and total energy calibration.

## Effect of coarser data

At 15-minute resolution, short cycles and narrow peaks would be averaged together. Event
boundaries and peak power would become less precise, while broad daily timing and energy
totals could remain useful after recalibration. At 30-minute resolution, several cycles
or overlapping appliances may fall in the same interval; appliance identification and
ON/OFF scoring would degrade further. A coarser-data model should therefore be trained
and evaluated at that resolution, with interval energy as the primary target rather than
minute-level power. More frequent labels, appliance metadata, and local Indian pilot data
would most improve confidence.

## Recommended next step

Collect a small labelled pilot with appliance submeters, validate across multiple held-out
homes, calibrate event energy, and compare 1-, 15-, and 30-minute models before making
customer-facing claims.

## Research basis

The NILM approach follows the non-stationarity-aware design in Petralia et al.,
“NILMFormer: Non-Intrusive Load Monitoring that Accounts for Non-Stationarity,” KDD
2025 ([paper](https://arxiv.org/abs/2506.05880); [official code](https://github.com/adrienpetralia/NILMFormer)).
The implementation adopts window stationarization, timestamp-aware encoding, and
statistics-based de-stationarization, adapted to one-minute REFIT data.
