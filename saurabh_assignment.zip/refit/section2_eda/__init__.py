"""Section 2: washing-machine exploratory analysis."""
