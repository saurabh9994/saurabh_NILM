"""Exploratory analysis of washing-machine use in official REFIT clean data."""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

# Mapping follows the REFIT appliance-list metadata. House 4 has two washing
# machines, so both monitored channels are summed for a household-level view.
WASHING_MACHINE_CHANNELS = {
    1: ["Appliance5"], 2: ["Appliance2"], 3: ["Appliance6"],
    4: ["Appliance4", "Appliance5"], 5: ["Appliance3"], 6: ["Appliance2"],
    7: ["Appliance5"], 8: ["Appliance4"], 9: ["Appliance3"],
    10: ["Appliance5"], 11: ["Appliance3"], 13: ["Appliance3"],
    20: ["Appliance4"],
}
DEFAULT_HOUSES = sorted(WASHING_MACHINE_CHANNELS)
ACTIVE_THRESHOLD_W = 10.0
MAX_EVENT_GAP_MINUTES = 2


def load_house(clean_root: Path, house: int) -> pd.DataFrame:
    channels = WASHING_MACHINE_CHANNELS[house]
    usecols = ["Time", "Aggregate", *channels]
    frame = pd.read_csv(clean_root / f"CLEAN_House{house}.csv", usecols=usecols)
    frame["Time"] = pd.to_datetime(frame["Time"], errors="coerce")
    frame = frame.dropna(subset=["Time"]).sort_values("Time").drop_duplicates("Time", keep="last")
    frame = frame.set_index("Time")
    for column in frame.columns:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")
    frame["WashingMachine"] = frame[channels].sum(axis=1, min_count=1)
    return frame[["Aggregate", "WashingMachine"]].resample("1min").mean()


def detect_events(series: pd.Series) -> pd.DataFrame:
    active = series.fillna(0).gt(ACTIVE_THRESHOLD_W)
    time_gap = series.index.to_series().diff().dt.total_seconds().div(60).fillna(1)
    group = (active.ne(active.shift()) | (time_gap.gt(MAX_EVENT_GAP_MINUTES) & active)).cumsum()
    records = []
    for _, values in series[active].groupby(group[active]):
        if values.empty:
            continue
        records.append({
            "start": values.index[0], "end": values.index[-1],
            "duration_min": (values.index[-1] - values.index[0]).total_seconds() / 60 + 1,
            "peak_w": float(values.max()), "energy_wh": float(values.sum() / 60),
        })
    return pd.DataFrame(records, columns=["start", "end", "duration_min", "peak_w", "energy_wh"])


def summarize_house(house: int, frame: pd.DataFrame, events: pd.DataFrame) -> dict:
    gaps = frame.index.to_series().diff().dt.total_seconds().div(60)
    missing = frame["WashingMachine"].isna()
    return {
        "house": house, "start": str(frame.index.min()), "end": str(frame.index.max()),
        "one_minute_rows": int(len(frame)), "missing_washing_machine_minutes": int(missing.sum()),
        "missing_interval_fraction": float(missing.mean()), "off_time_fraction": float((frame.WashingMachine.fillna(0) <= ACTIVE_THRESHOLD_W).mean()),
        "intervals_over_2_minutes": int(gaps.gt(2).sum()), "detected_events": int(len(events)),
        "median_duration_min": float(events.duration_min.median()) if len(events) else None,
        "median_peak_w": float(events.peak_w.median()) if len(events) else None,
        "median_energy_wh": float(events.energy_wh.median()) if len(events) else None,
    }


def save_plots(frames: dict[int, pd.DataFrame], events: pd.DataFrame, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    first_house = next(iter(frames))
    first = frames[first_house]
    day = first.loc[first.index.min():first.index.min() + pd.Timedelta(days=1)]
    fig, ax = plt.subplots(figsize=(13, 4)); ax.plot(day.index, day.Aggregate, label="aggregate", lw=.7); ax.plot(day.index, day.WashingMachine, label="washing machine", lw=1); ax.set_ylabel("Power (W)"); ax.legend(); ax.set_title(f"House {first_house}: representative 24-hour trace"); fig.tight_layout(); fig.savefig(output_dir / "representative_24h_trace.png", dpi=160); plt.close(fig)

    event_house = events.house.iloc[0] if len(events) else first_house
    event = events[events.house == event_house].iloc[0] if len(events) else None
    if event is not None:
        trace = frames[event_house].loc[event.start - pd.Timedelta(minutes=15):event.end + pd.Timedelta(minutes=15)]
        fig, ax = plt.subplots(figsize=(12, 4)); ax.plot(trace.index, trace.WashingMachine, lw=1); ax.axvspan(event.start, event.end, color="orange", alpha=.25, label="detected event"); ax.set_ylabel("Power (W)"); ax.set_title(f"House {event_house}: detected washing-machine event"); ax.legend(); fig.tight_layout(); fig.savefig(output_dir / "representative_cycle.png", dpi=160); plt.close(fig)

    hourly = pd.concat([f.assign(house=h) for h, f in frames.items()]).assign(hour=lambda x: x.index.hour).groupby("hour").WashingMachine.mean()
    weekday = pd.concat([f.assign(house=h) for h, f in frames.items()]).assign(day=lambda x: x.index.day_name()).groupby("day").WashingMachine.mean().reindex(["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"])
    fig, ax = plt.subplots(1, 2, figsize=(13, 4)); hourly.plot(ax=ax[0], marker="o"); ax[0].set_title("Mean washing-machine power by hour"); ax[0].set_ylabel("Mean W"); weekday.plot(ax=ax[1], kind="bar"); ax[1].set_title("Mean washing-machine power by day"); ax[1].set_ylabel("Mean W"); fig.tight_layout(); fig.savefig(output_dir / "usage_by_hour_and_day.png", dpi=160); plt.close(fig)

    if len(events):
        comparison = events.groupby("house")[["energy_wh", "duration_min", "peak_w"]].median()
        comparison.plot(kind="bar", subplots=True, figsize=(12, 8), legend=False, title=["Median cycle energy (Wh)", "Median duration (min)", "Median peak power (W)"])
        plt.tight_layout(); plt.savefig(output_dir / "cycle_comparison_by_house.png", dpi=160); plt.close()


def run(clean_root: Path, output_dir: Path, houses: list[int] | None = None) -> dict:
    houses = houses or DEFAULT_HOUSES
    frames, summaries, event_frames = {}, [], []
    for house in houses:
        if house not in WASHING_MACHINE_CHANNELS:
            raise ValueError(f"No verified washing-machine mapping configured for House {house}.")
        frame = load_house(clean_root, house); events = detect_events(frame.WashingMachine); events["house"] = house
        frames[house] = frame; summaries.append(summarize_house(house, frame, events)); event_frames.append(events)
    events = pd.concat(event_frames, ignore_index=True) if event_frames else pd.DataFrame()
    output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(summaries).to_csv(output_dir / "washing_machine_house_summary.csv", index=False)
    events.to_csv(output_dir / "washing_machine_events.csv", index=False)
    save_plots(frames, events, output_dir)
    report = {"houses": houses, "threshold_w": ACTIVE_THRESHOLD_W, "max_event_gap_minutes": MAX_EVENT_GAP_MINUTES, "channel_mapping": {str(k): v for k, v in WASHING_MACHINE_CHANNELS.items()}, "summary": summaries}
    (output_dir / "section2_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report
