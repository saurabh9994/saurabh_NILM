# Section 2 — Washing-machine exploratory analysis

Run from the project root:

```text
python refit/main.py --section 2
```

The default analysis uses the official cleaned files for Houses 1–11, 13, and 20, where the washing-machine channel mapping is configured from the REFIT appliance metadata. House 4 has two monitored washing machines and combines both channels. Override the selection with, for example, `python refit/main.py --section 2 --houses 1 2 3 4 5`.

The active-event rule is washing-machine power above 10 W, with short gaps up to two minutes allowed inside an event. For each home the pipeline reports date coverage, one-minute row count, missing intervals, missing fraction, off-time fraction, long gaps, event count, median duration, median peak power, and median energy per event.

Outputs in `outputs/section2/`:

- `section2_report.json` and `washing_machine_house_summary.csv`
- `washing_machine_events.csv`
- `representative_24h_trace.png`
- `representative_cycle.png`
- `usage_by_hour_and_day.png`
- `cycle_comparison_by_house.png`

Energy is calculated as the one-minute mean power summed over minutes and divided by 60. These are detected operating events, not guaranteed manufacturer-defined wash cycles. Monitored appliance identity can change during the REFIT period, and missing/outage periods are reported rather than silently treated as zero.
