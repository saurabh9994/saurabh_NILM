"""REFIT take-home assignment package."""
