# Section 4 — Practical implications

Run from the project root:

```text
python refit/main.py --section 4
```

This generates `outputs/section4/Recommendation.md` from the Section 2 event summary
and Section 3 model comparison. It explains a measurable peak-shifting opportunity,
appropriate and inappropriate uses of the current model, limitations, and expected
degradation at 15- and 30-minute resolution.
