"""Generate the practical-implications deliverable from Sections 2 and 3 outputs."""
from __future__ import annotations

import json
from pathlib import Path


def _read_json(path: Path, fallback: dict) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        return fallback


def run(project_root: Path, output_root: Path) -> Path:
    section2 = _read_json(project_root / "outputs" / "section2" / "section2_report.json", {})
    section3 = _read_json(project_root / "outputs" / "section3" / "model_comparison.json", {})
    summaries = section2.get("summary", [])
    models = section3.get("metrics", section3.get("results", [])) if isinstance(section3, dict) else section3
    best = min(models, key=lambda row: row.get("MAE_W", float("inf"))) if models else {}

    house_text = ", ".join(str(row.get("house")) for row in summaries) or "the available evaluated homes"
    evidence = "No Section 2 summary was found; rerun Sections 2 and 3 to populate measured evidence."
    if summaries:
        row = summaries[0]
        evidence = (
            f"For House {row.get('house')}, the available summary reports {row.get('detected_events', 'n/a'):,} "
            f"detected events, a median duration of {row.get('median_duration_min', 'n/a')} minutes, "
            f"median event energy of {row.get('median_energy_wh', 'n/a'):.1f} Wh, and "
            f"{row.get('off_time_fraction', 0) * 100:.1f}% off-time."
        )
    model_text = "Model metrics are not available."
    if best:
        model_text = (
            f"The best recorded model by MAE is {best.get('model', 'unknown')}: "
            f"MAE {best.get('MAE_W', float('nan')):.1f} W, "
            f"RMSE {best.get('RMSE_W', float('nan')):.1f} W, and "
            f"ON/OFF F1 {best.get('on_off_f1', float('nan')):.3f}."
        )

    output_root.mkdir(parents=True, exist_ok=True)
    report = output_root / "Recommendation.md"
    report.write_text(f"""# Practical implications and recommendation

## Evidence and suitable use

The current washing-machine analysis covers {house_text}. {evidence} {model_text}

The model is suitable as an **aggregate-load screening signal**: it can help identify
likely washing-machine activity windows and compare usage patterns over groups of homes.
It is not reliable enough in its current form for appliance-level billing, customer
penalties, or automated control. The very low ON/OFF F1 means predicted events should
be reviewed or aggregated before being acted on.

## Energy-saving opportunity

A practical opportunity is to shift discretionary washing-machine cycles away from
the utility's peak period, or to encourage full-load and eco-cycle operation. The
recommended pilot is a time-of-use message or app prompt offered after a detected
cycle, with no automatic appliance control initially.

Measure impact with a pre/post comparison: record washing-machine event count, energy
per event, start-time distribution, and household aggregate evening peak demand for
four weeks before and four weeks after the intervention. Use comparable control homes
or a difference-in-differences design, and report confidence intervals. Ground-truth
submeter readings are preferable for the pilot; the NILM output should be treated as
an estimator and audited against labels.

## Limitations

- Multiple appliances can overlap in the aggregate signal, producing ambiguous signatures.
- Missing intervals and unmetered loads can hide or distort events; missingness must not be treated as zero use.
- One-minute data smooths short transients and may miss start/stop details.
- Household routines, appliance replacement, occupancy, and seasonality limit transfer between homes.
- The REFIT homes are UK homes. Appliance mix, voltage, tariffs, climate, and behaviour differ in India, so the findings should not be generalized without local validation.
- The current model's held-out performance is weak, especially for event classification and total energy calibration.

## Effect of coarser data

At 15-minute resolution, short cycles and narrow peaks would be averaged together. Event
boundaries and peak power would become less precise, while broad daily timing and energy
totals could remain useful after recalibration. At 30-minute resolution, several cycles
or overlapping appliances may fall in the same interval; appliance identification and
ON/OFF scoring would degrade further. A coarser-data model should therefore be trained
and evaluated at that resolution, with interval energy as the primary target rather than
minute-level power. More frequent labels, appliance metadata, and local Indian pilot data
would most improve confidence.

## Recommended next step

Collect a small labelled pilot with appliance submeters, validate across multiple held-out
homes, calibrate event energy, and compare 1-, 15-, and 30-minute models before making
customer-facing claims.
""", encoding="utf-8")
    return report


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    print(run(root, root / "outputs" / "section4"))
