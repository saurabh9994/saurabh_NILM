"""Comparable Seq2Point, Seq2Seq and TCN baselines for REFIT washing machines.

The default experiment trains on Houses 1--3 and evaluates on unseen House 4.
The same one-minute windows, target scaling, epochs, metrics and held-out
house are used for all models. This makes the comparison meaningful while
remaining runnable on a workstation.
"""
from __future__ import annotations

import json
import random
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

try:
    from section2_eda.section2 import WASHING_MACHINE_CHANNELS
except ModuleNotFoundError:  # Also support `python -m refit.main`.
    from ..section2_eda.section2 import WASHING_MACHINE_CHANNELS

SEED = 42
WINDOW = 31
POWER_SCALE = 3000.0
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def seed_everything(seed=SEED):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)


def load_minute(clean_root: Path, house: int) -> pd.DataFrame:
    channels = WASHING_MACHINE_CHANNELS[house]
    frame = pd.read_csv(clean_root / f"CLEAN_House{house}.csv", usecols=["Time", "Aggregate", *channels])
    frame["Time"] = pd.to_datetime(frame["Time"], errors="coerce")
    frame = frame.dropna(subset=["Time"]).sort_values("Time").drop_duplicates("Time", keep="last").set_index("Time")
    frame = frame.apply(pd.to_numeric, errors="coerce")
    frame["target"] = frame[channels].sum(axis=1, min_count=1)
    # Consistent one-minute preprocessing for input and label; do not fill long outages.
    return frame[["Aggregate", "target"]].resample("1min").mean().interpolate(limit=2, limit_area="inside").dropna()


def make_windows(frame: pd.DataFrame, max_samples: int | None = None):
    x = frame.Aggregate.to_numpy(dtype=np.float32) / POWER_SCALE
    y = frame.target.to_numpy(dtype=np.float32) / POWER_SCALE
    half = WINDOW // 2
    starts = np.arange(0, len(frame) - WINDOW + 1)
    if max_samples and len(starts) > max_samples:
        rng = np.random.default_rng(SEED); starts = np.sort(rng.choice(starts, max_samples, replace=False))
    X = np.stack([x[s:s+WINDOW] for s in starts])[:, None, :]
    Y = np.stack([y[s:s+WINDOW] for s in starts])
    # Discrete timestamp inputs used by NILMFormer's TimeRPE: minute, hour,
    # day-of-week and month. Keep them as normalized continuous calendar values
    # so the model can apply sinusoidal projections without a learned absolute
    # position embedding.
    stamps = frame.index[starts]
    time_rows = []
    for stamp in stamps:
        times = pd.date_range(stamp, periods=WINDOW, freq="1min")
        time_rows.append(np.stack([
            times.minute.to_numpy() / 59.0,
            times.hour.to_numpy() / 23.0,
            times.dayofweek.to_numpy() / 6.0,
            (times.month.to_numpy() - 1) / 11.0,
        ], axis=1))
    T = np.stack(time_rows).astype(np.float32)
    return X, Y, frame.index[starts + half], T


class Seq2Point(nn.Module):
    def __init__(self):
        super().__init__(); self.net = nn.Sequential(nn.Conv1d(1, 32, 5, padding=2), nn.ReLU(), nn.Conv1d(32, 64, 5, padding=2), nn.ReLU(), nn.Flatten(), nn.Linear(64*WINDOW, 64), nn.ReLU(), nn.Linear(64, 1))
    def forward(self, x): return self.net(x).squeeze(-1)


class Seq2Seq(nn.Module):
    def __init__(self):
        super().__init__(); self.net = nn.Sequential(nn.Conv1d(1, 32, 5, padding=2), nn.ReLU(), nn.Conv1d(32, 64, 5, padding=2), nn.ReLU(), nn.Conv1d(64, 1, 1))
    def forward(self, x): return self.net(x).squeeze(1)


class DeepCNN(nn.Module):
    """Deeper residual CNN predicting the centre minute of a window."""
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(1, 32, 3, padding=1), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 5, padding=2), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 64, 3, padding=2, dilation=2), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 96, 3, padding=4, dilation=4), nn.BatchNorm1d(96), nn.ReLU(),
        )
        self.head = nn.Sequential(nn.Flatten(), nn.Linear(96 * WINDOW, 128), nn.ReLU(), nn.Dropout(0.15))
        self.regression = nn.Linear(128, 1)
        self.activity = nn.Linear(128, 1)

    def forward(self, x):
        h = self.head(self.features(x))
        return self.regression(h).squeeze(-1), self.activity(h).squeeze(-1)


class TCNBlock(nn.Module):
    def __init__(self, channels, dilation):
        super().__init__(); pad = dilation * 2
        self.net = nn.Sequential(nn.Conv1d(channels, channels, 3, padding=pad, dilation=dilation), nn.ReLU(), nn.Conv1d(channels, channels, 3, padding=pad, dilation=dilation), nn.ReLU())
    def forward(self, x):
        y = self.net(x); trim = (y.size(-1) - x.size(-1)) // 2
        return y[..., trim:trim+x.size(-1)] + x


class TCN(nn.Module):
    def __init__(self):
        super().__init__(); self.inp = nn.Conv1d(1, 32, 1); self.blocks = nn.Sequential(TCNBlock(32,1), TCNBlock(32,2), TCNBlock(32,4)); self.out = nn.Conv1d(32,1,1)
    def forward(self, x): return self.out(self.blocks(self.inp(x))).squeeze(1)


class TimeRPE(nn.Module):
    """Timestamp-only periodic encoding described in NILMFormer."""
    def __init__(self, out_dim):
        super().__init__()
        self.proj = nn.Conv1d(8, out_dim, kernel_size=1)

    def forward(self, timestamp_features):
        angles = timestamp_features.unsqueeze(-1) * (2 * np.pi)
        periodic = torch.cat([torch.sin(angles), torch.cos(angles)], dim=-1)
        periodic = periodic.flatten(-2).transpose(1, 2)
        return self.proj(periodic).transpose(1, 2)


class NILMFormer(nn.Module):
    """NILMFormer-style seq2seq model for one-minute REFIT windows.

    The data path follows the paper: stationarize -> robust convolutional
    extractor -> concatenate TokenStats and TimeRPE -> Transformer -> Head ->
    ProjStats-based de-stationarization.
    """
    def __init__(self):
        super().__init__()
        d_model = 64
        self.extractor = nn.Sequential(
            nn.Conv1d(1, 32, 5, padding=2), nn.GELU(),
            nn.Conv1d(32, d_model, 3, padding=1), nn.GELU(),
        )
        self.token_stats = nn.Linear(2, d_model)
        self.time_rpe = TimeRPE(d_model)
        layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=4, dim_feedforward=128,
                                           dropout=0.1, batch_first=True, norm_first=True)
        self.transformer = nn.TransformerEncoder(layer, num_layers=2)
        self.head = nn.Sequential(nn.Linear(d_model, d_model), nn.GELU(), nn.Linear(d_model, 1))
        self.proj_stats = nn.Linear(2, 2)
        # Stable start: predict a zero appliance signal while retaining a unit
        # output scale. A random affine de-stationarization layer can otherwise
        # turn mostly-off windows into large positive wattage predictions.
        nn.init.zeros_(self.proj_stats.weight)
        nn.init.constant_(self.proj_stats.bias, 0.0)

    def forward(self, x, timestamps):
        signal = x.squeeze(1)
        mean = signal.mean(dim=1, keepdim=True)
        std = signal.std(dim=1, keepdim=True).clamp_min(1e-4)
        stationary = ((signal - mean) / std).unsqueeze(1)
        shape_tokens = self.extractor(stationary).transpose(1, 2)
        stats = torch.cat([mean, std], dim=1)
        shape_tokens = shape_tokens + self.token_stats(stats).unsqueeze(1)
        shape_tokens = shape_tokens + self.time_rpe(timestamps)
        encoded = self.transformer(shape_tokens)
        normalized_prediction = self.head(encoded).squeeze(-1)
        output_stats = self.proj_stats(stats)
        output_scale = torch.exp(output_stats[:, 1:2]).clamp(0.05, 3.0)
        return normalized_prediction * output_scale + output_stats[:, 0:1]


def metrics(actual, predicted):
    actual = np.asarray(actual); predicted = np.clip(np.asarray(predicted), 0, None)
    on_a, on_p = actual > 10, predicted > 10
    tp = (on_a & on_p).sum(); fp = (~on_a & on_p).sum(); fn = (on_a & ~on_p).sum()
    precision = tp / (tp + fp) if tp + fp else 0.0; recall = tp / (tp + fn) if tp + fn else 0.0
    return {"MAE_W": float(np.mean(np.abs(actual-predicted))), "RMSE_W": float(np.sqrt(np.mean((actual-predicted)**2))), "R2": float(1 - np.sum((actual-predicted)**2) / max(np.sum((actual-actual.mean())**2), 1e-9)), "energy_error_pct": float(100*(predicted.sum()-actual.sum())/max(actual.sum(),1e-9)), "on_off_f1": float(2*precision*recall/max(precision+recall,1e-9)), "actual_energy_kWh": float(actual.sum()/60/1000), "predicted_energy_kWh": float(predicted.sum()/60/1000)}


def fit_model(name, model, train_loader, test_x, test_y, test_times, test_t, epochs, output_dir, verbose=True):
    model = model.to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3); loss_fn = nn.MSELoss(); model.train()
    history=[]
    for epoch in range(epochs):
        total=0
        for batch in train_loader:
            xb, yb, tb = (value.to(DEVICE) for value in batch)
            optimizer.zero_grad()
            if name == "nilmformer": out = model(xb, tb); target = yb
            else: out=model(xb); target=yb[:, WINDOW//2] if name in {"seq2point", "cnn"} else yb
            if name == "cnn":
                regression, activity_logit = out
                activity_target = target.gt(10.0 / POWER_SCALE).float()
                regression_loss = nn.functional.smooth_l1_loss(regression, target)
                activity_loss = nn.functional.binary_cross_entropy_with_logits(activity_logit, activity_target)
                loss = regression_loss + 0.5 * activity_loss
            else:
                loss = loss_fn(out,target)
            loss.backward(); optimizer.step(); total += loss.item()*len(xb)
        epoch_loss = total/len(train_loader.dataset); history.append(epoch_loss)
        if verbose:
            model.eval()
            with torch.no_grad():
                if name == "nilmformer":
                    validation_out = model(torch.from_numpy(test_x).to(DEVICE), torch.from_numpy(test_t).to(DEVICE)).cpu().numpy()
                else:
                    validation_out = model(torch.from_numpy(test_x).to(DEVICE))
                    if name == "cnn":
                        validation_out = validation_out[0].cpu().numpy()
                    else:
                        validation_out = validation_out.cpu().numpy()
            validation_pred = validation_out if name not in {"seq2point", "cnn"} else np.repeat(validation_out[:, None], WINDOW, axis=1)
            validation_actual = test_y[:, WINDOW // 2] * POWER_SCALE
            validation_prediction = validation_pred[:, WINDOW // 2] * POWER_SCALE
            validation_metrics = metrics(validation_actual, validation_prediction)
            print(
                f"[{name}] epoch {epoch + 1:02d}/{epochs} - "
                f"loss: {epoch_loss:.6f} - "
                f"val_MAE: {validation_metrics['MAE_W']:.2f} W - "
                f"val_RMSE: {validation_metrics['RMSE_W']:.2f} W - "
                f"val_F1: {validation_metrics['on_off_f1']:.3f}",
                flush=True,
            )
            model.train()
    model.eval()
    with torch.no_grad():
        if name == "nilmformer": out=model(torch.from_numpy(test_x).to(DEVICE), torch.from_numpy(test_t).to(DEVICE))
        else: out=model(torch.from_numpy(test_x).to(DEVICE))
        if name == "cnn": out=out[0]
        out=out.cpu().numpy()
    pred = out if name not in {"seq2point", "cnn"} else np.repeat(out[:,None], WINDOW, axis=1)
    # Evaluate the center minute for all models, avoiding overlap double-counting.
    actual = test_y[:, WINDOW//2] * POWER_SCALE; predicted = pred[:, WINDOW//2] * POWER_SCALE
    result = metrics(actual, predicted); result.update({"model": name, "epochs": epochs, "training_loss": history[-1]})
    pd.DataFrame({"time": test_times, "actual_w": actual, "predicted_w": np.clip(predicted,0,None)}).to_csv(output_dir / f"{name}_predictions.csv", index=False)
    return result, history


def run(clean_root: Path, output_dir: Path, train_houses=None, test_house=4, epochs=3, max_samples=60000, selected_models=None):
    seed_everything(); print(f"Using device: {DEVICE}", flush=True); train_houses = train_houses or [1,2,3]; output_dir.mkdir(parents=True, exist_ok=True)
    train_parts = [make_windows(load_minute(clean_root,h), max_samples=max_samples//len(train_houses)) for h in train_houses]
    train_x=np.concatenate([p[0] for p in train_parts]); train_y=np.concatenate([p[1] for p in train_parts]); train_t=np.concatenate([p[3] for p in train_parts]); test_limit = max_samples if selected_models and "nilmformer" in selected_models else None; test_x,test_y,test_times,test_t=make_windows(load_minute(clean_root,test_house), max_samples=test_limit)
    loader=DataLoader(TensorDataset(torch.from_numpy(train_x),torch.from_numpy(train_y),torch.from_numpy(train_t)),batch_size=256,shuffle=True)
    all_models={"seq2point":Seq2Point,"seq2seq":Seq2Seq,"tcn":TCN,"cnn":DeepCNN,"nilmformer":NILMFormer}
    selected_models = selected_models or list(all_models)
    unknown = sorted(set(selected_models) - set(all_models))
    if unknown: raise ValueError(f"Unknown model(s): {unknown}")
    models={name: all_models[name]() for name in selected_models}; rows=[]; histories={}
    for name, model in models.items():
        row, history=fit_model(name,model,loader,test_x,test_y,test_times,test_t,epochs,output_dir); rows.append(row); histories[name]=history
    pd.DataFrame(rows).to_csv(output_dir / "model_comparison.csv", index=False); (output_dir / "model_comparison.json").write_text(json.dumps({"train_houses":train_houses,"test_house":test_house,"window_minutes":WINDOW,"epochs":epochs,"metrics":rows},indent=2),encoding="utf-8")
    fig, ax=plt.subplots(figsize=(14,5)); n=min(len(test_times),7*24*60); ax.plot(test_times[:n],test_y[:n,WINDOW//2]*POWER_SCALE,label="actual",lw=1); 
    for name in models: p=pd.read_csv(output_dir/f"{name}_predictions.csv"); ax.plot(pd.to_datetime(p.time.iloc[:n]),p.predicted_w.iloc[:n],label=name,lw=.8)
    ax.set_ylabel("W"); ax.set_title(f"Held-out House {test_house}: model comparison"); ax.legend(); fig.tight_layout(); fig.savefig(output_dir/"model_comparison_trace.png",dpi=160); plt.close(fig)
    return rows
