# Section 3 — Washing-machine NILM

Run the comparison:

```text
python refit/main.py --section 3 --train-houses 1 2 3 --test-house 4 --epochs 10
```

To train NILMFormer:

```text
python refit/main.py --section 3 --models nilmformer --train-houses 1 2 3 --test-house 4 --epochs 10
```

The pipeline uses one-minute means from the official cleaned files, the washing-machine mapping from Section 2, a 31-minute aggregate window, and non-overlapping household roles: Houses 1–3 are training data and House 4 is entirely held out. No windows from the test home are used during training. Short internal gaps are interpolated up to two minutes; longer outages are dropped from model windows.

Three models are trained independently with the same data and optimizer budget:

- **Seq2Point:** convolutional encoder predicts the center washing-machine minute.
- **Seq2Seq:** convolutional encoder predicts the full 31-minute target sequence; its center minute is used for the comparable score.
- **TCN:** causal-style dilated residual convolution blocks predict the full sequence; its center minute is scored.
- **CNN:** deeper residual-style convolutional regressor with batch normalization, dilated filters, dropout, and a centre-minute output.
- **NILMFormer:** sequence-to-sequence Transformer following Petralia et al. (KDD 2025): window stationarization, convolutional shape extraction, statistics token, timestamp-only TimeRPE, Transformer encoder, and statistics-based output de-stationarization.

Metrics are MAE, RMSE, R², relative energy error, and ON/OFF F1 using 10 W. Energy predictions are clipped at zero for reporting. The aggregate signal is the only model input; appliance channels are labels only. Use `model_comparison.csv`, per-model prediction CSVs, and `model_comparison_trace.png` for comparison and failure analysis.

This is a compact baseline for the assignment, not a claim of production-grade NILM. Increasing epochs, tuning window length, validating on multiple held-out homes, and adding confidence intervals would be sensible next steps.

Reference: Petralia, Charpentier, Kadhi, and Palpanas, “NILMFormer: Non-Intrusive Load Monitoring that Accounts for Non-Stationarity,” KDD 2025, DOI: 10.1145/3711896.3737251. The implementation adapts the architecture to this assignment's one-minute REFIT input and existing held-out-house evaluation.
