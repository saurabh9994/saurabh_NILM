"""Section 3: washing-machine NILM model development and evaluation."""
