"""Main entry point for the REFIT assignment."""
from __future__ import annotations

import argparse
from pathlib import Path

from section1_cleaning.section1 import run as run_section1
from section2_eda.section2 import DEFAULT_HOUSES, run as run_section2
from section3_nilm.section3 import run as run_section3
from section4_implications.section4 import run as run_section4


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser(description="Run REFIT assignment sections.")
    parser.add_argument("--section", choices=["1", "2", "3", "4", "all"], default="1")
    parser.add_argument("--data-root", type=Path, default=PROJECT_ROOT / "REFIT_RAW_081116")
    parser.add_argument("--output-root", type=Path, default=PROJECT_ROOT / "outputs" / "section1")
    parser.add_argument("--houses", type=int, nargs="+", default=DEFAULT_HOUSES, help="House IDs for Section 2")
    parser.add_argument("--train-houses", type=int, nargs="+", default=[1, 2, 3], help="Training houses for Section 3")
    parser.add_argument("--test-house", type=int, default=4, help="Held-out test house for Section 3")
    parser.add_argument("--epochs", type=int, default=10, help="Training epochs per Section 3 model")
    parser.add_argument("--models", nargs="+", choices=["seq2point", "seq2seq", "tcn", "cnn", "nilmformer"], default=None, help="Section 3 models to train; default is all five")
    args = parser.parse_args()

    if args.section in {"1", "all"}:
        report = run_section1(args.data_root, args.output_root, house=1)
        print(f"Section 1 complete. Outputs written to: {args.output_root}")
        print(f"Rows: {report['rows_before_cleaning']:,} raw -> {report['rows_after_resampling']:,} one-minute rows")
    if args.section in {"2", "all"}:
        section2_output = PROJECT_ROOT / "outputs" / "section2"
        report = run_section2(PROJECT_ROOT / "CLEAN_REFIT_081116", section2_output, args.houses)
        print(f"Section 2 complete for Houses {report['houses']}. Outputs written to: {section2_output}")
    if args.section in {"3", "all"}:
        section3_output = PROJECT_ROOT / "outputs" / "section3"
        rows = run_section3(PROJECT_ROOT / "CLEAN_REFIT_081116", section3_output, args.train_houses, args.test_house, args.epochs, selected_models=args.models)
        print(f"Section 3 complete. Metrics written to: {section3_output / 'model_comparison.csv'}")
        for row in rows: print(row["model"], "MAE_W=", round(row["MAE_W"], 2), "RMSE_W=", round(row["RMSE_W"], 2), "F1=", round(row["on_off_f1"], 3))
    if args.section in {"4", "all"}:
        report = run_section4(PROJECT_ROOT, PROJECT_ROOT / "outputs" / "section4")
        print(f"Section 4 complete. Recommendation written to: {report}")


if __name__ == "__main__":
    main()
