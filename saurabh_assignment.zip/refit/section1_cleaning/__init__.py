"""Section 1: raw House 1 inspection and cleaning."""
