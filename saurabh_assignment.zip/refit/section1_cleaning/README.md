# Section 1 — House 1 raw-data inspection and cleaning

This section uses only the supplied raw House 1 files. It does not use the official cleaned release.

Run from the project root:

```text
python refit/main.py --section 1
```

Generated artifacts are stored in `outputs/section1/`:

- `house1_quality_report.json` — timestamp, duplicate, interval, missing-value, negative-value, and extreme-value checks.
- `house1_clean_1min.csv` — sorted, deduplicated, one-minute data.
- `house1_before_after_cleaning.png` — aggregate, Appliance 1, and Appliance 3 before/after plots.

Cleaning decisions:

1. Parse timestamps and remove rows with invalid timestamps.
2. Sort chronologically.
3. Remove duplicate timestamps while keeping the last reading.
4. Resample all available power channels to one-minute arithmetic means.
5. Interpolate only up to two consecutive missing minutes.
6. Leave longer gaps as missing and report them rather than fabricating readings.
