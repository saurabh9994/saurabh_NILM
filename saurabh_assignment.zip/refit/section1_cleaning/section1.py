"""Section 1 pipeline: inspect and clean raw REFIT House 1 data.

This module deliberately uses only the raw House 1 files. It produces a
machine-readable quality report, a one-minute cleaned CSV, and diagnostic
plots suitable for the assignment submission.
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


POWER_COLUMNS = ["Aggregate"] + [f"Appliance{i}" for i in range(1, 10)]


def raw_paths(data_root: Path, house: int = 1) -> list[Path]:
    """Return the two raw REFIT parts for a household."""
    return [
        data_root / f"RAW_House{house}_Part1.csv",
        data_root / f"RAW_House{house}_Part2.csv",
    ]


def load_raw(data_root: Path, house: int = 1) -> pd.DataFrame:
    """Load, concatenate, and minimally parse raw readings."""
    paths = raw_paths(data_root, house)
    missing = [str(path) for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing raw input file(s): {missing}")

    frames = [pd.read_csv(path) for path in paths]
    frame = pd.concat(frames, ignore_index=True)
    time_column = next(
        (column for column in frame.columns if column.lower() in {"time", "timestamp", "datetime"}),
        None,
    )
    if time_column is None:
        raise ValueError("Could not identify the raw timestamp column.")
    frame["Time"] = pd.to_datetime(frame[time_column], errors="coerce")
    frame = frame.dropna(subset=["Time"])
    return frame


def quality_report(raw: pd.DataFrame) -> dict:
    """Calculate inspection statistics before cleaning."""
    ordered_time = raw["Time"].sort_values()
    intervals = ordered_time.diff().dt.total_seconds().dropna()
    power = raw[[column for column in POWER_COLUMNS if column in raw.columns]].apply(
        pd.to_numeric, errors="coerce"
    )
    return {
        "house": 1,
        "rows_before_cleaning": int(len(raw)),
        "invalid_timestamps": int(raw["Time"].isna().sum()),
        "duplicate_timestamps": int(raw["Time"].duplicated().sum()),
        "start": str(raw["Time"].min()),
        "end": str(raw["Time"].max()),
        "interval_seconds": {
            "p01": float(intervals.quantile(0.01)),
            "median": float(intervals.quantile(0.50)),
            "p99": float(intervals.quantile(0.99)),
            "zero_or_negative": int((intervals <= 0).sum()),
        },
        "missing_power_cells": int(power.isna().sum().sum()),
        "negative_power_cells": int((power < 0).sum().sum()),
        "power_values_over_30kw": int((power > 30_000).sum().sum()),
    }


def clean_to_minute(raw: pd.DataFrame) -> pd.DataFrame:
    """Sort, deduplicate, resample to 1-minute means, fill only short gaps."""
    working = raw[["Time"] + [c for c in POWER_COLUMNS if c in raw.columns]].copy()
    for column in working.columns[1:]:
        working[column] = pd.to_numeric(working[column], errors="coerce")
    working = working.sort_values("Time").drop_duplicates("Time", keep="last")
    working = working.set_index("Time")
    minute = working.resample("1min").mean()
    # A gap limit of two means only runs of <=2 missing minutes are filled.
    # Longer outages remain NaN and are reported to the user.
    return minute.interpolate(limit=2, limit_direction="both", limit_area="inside")


def save_plots(raw: pd.DataFrame, cleaned: pd.DataFrame, output_dir: Path) -> None:
    """Save before/after plots for aggregate and two appliance channels."""
    output_dir.mkdir(parents=True, exist_ok=True)
    raw_plot = raw.set_index("Time").sort_index()
    start = cleaned.index.min()
    end = start + pd.Timedelta(days=1)
    before = raw_plot.loc[start:end]
    after = cleaned.loc[start:end]
    channels = [column for column in ["Aggregate", "Appliance1", "Appliance3"] if column in cleaned]

    fig, axes = plt.subplots(len(channels), 2, figsize=(15, 3 * len(channels)), squeeze=False)
    for row, channel in enumerate(channels):
        axes[row, 0].plot(before.index, before[channel], linewidth=0.6)
        axes[row, 0].set_title(f"Before cleaning: {channel}")
        axes[row, 1].plot(after.index, after[channel], linewidth=0.8)
        axes[row, 1].set_title(f"After cleaning and 1-minute resampling: {channel}")
        for col in range(2):
            axes[row, col].set_ylabel("Power (W)")
            axes[row, col].grid(alpha=0.2)
    fig.tight_layout()
    fig.savefig(output_dir / "house1_before_after_cleaning.png", dpi=160)
    plt.close(fig)


def run(data_root: Path, output_dir: Path, house: int = 1) -> dict:
    """Run all Section 1 steps and return the final report."""
    raw = load_raw(data_root, house)
    report = quality_report(raw)
    cleaned = clean_to_minute(raw)
    report.update({
        "rows_after_resampling": int(len(cleaned)),
        "remaining_rows_with_missing_values": int(cleaned.isna().any(axis=1).sum()),
        "cleaning_rules": {
            "sort_by": "Time ascending",
            "duplicate_rule": "keep last reading for duplicate timestamp",
            "resampling": "one-minute arithmetic mean",
            "short_gap_interpolation": "at most two consecutive missing minutes",
            "long_gap_policy": "leave missing and flag in report",
        },
    })
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "house1_quality_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    cleaned.to_csv(output_dir / "house1_clean_1min.csv", index_label="Time")
    save_plots(raw, cleaned, output_dir)
    return report
